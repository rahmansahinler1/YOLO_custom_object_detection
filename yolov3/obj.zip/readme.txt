This is a sample train dataset.
I set this empty because dataset was including some confidential data.
This folder should has image-text files.
You can create this folder with labelImg.